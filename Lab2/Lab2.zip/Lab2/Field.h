﻿#pragma once
#include <iostream>

class Field
{
private:
	int Queens[8];
public:
	Field();
	Field(const int Queens[8]);
	Field(const Field& field);
	int GetQueenPosition(int QueenNumber) { return Queens[QueenNumber]; }
	void mooveQueen(int QueenNumber, int position);  //QueenNumber відповідає номеру стовпця, position відповідає номеру рядка
	void setQueensRandom();
	void display();
	bool CheckForSolution();
	bool operator==(Field field);
	friend int F2(Field field);
};

int countPairsInArr(int arr[], int n);

int Combination(int n, int m);